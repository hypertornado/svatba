Merci d'avoir t�l�charg� cette police. Vous pouvez l'utiliser librement, toutefois j'appr�cierais que vous me fassiez parvenir les travaux dans lesquels vous ferez appara�tre GrutchHanded. gruson.steeve@neuf.fr

Thank you for downloading this font. It's free-to-use but I would appreciate that you send me the works GrutchHanded appears in. gruson.steeve@neuf.fr
