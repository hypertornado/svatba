EN >>> You�ve just downloaded USIS 1949 font version 1.1 (3/31/2014), made of prints of United States Information Service reports from 1949.     

USIS 1949 font was created by Lukas Krakora and is free for non-commercial use only!

If you want to use this font commercially, please contact me at: 
krraaa@yahoo.com to get the information about pricing.

Please type "USIS 1949" in subject of your message.

I will also appreciate to receive any comments or pictures of your artwork using this font at the same address.  

Please feel free to distribute the font, but keep this readme file with it and do not change the font in any way!

Have fun! 

LK



CZ >>> Pr�v� jste si st�hli font USIS 1949 verze 1.1 (31/3/2014), vytvo�en� z tiskov�ch zpr�v United States Information Service z roku 1949.

Font USIS 1949 byl vytvo�en Luk�em Kr�korou a je voln� ke sta�en� a pou�it� av�ak pouze pro nekomer�n� ��ely!

V p��pad� z�m�ru vyu��t font komer�n� m� pros�m kontaktujte na emailu: 
krraaa@yahoo.com a dozv�te se cenu.

Pokud mi budete ps�t, nezapome�te do p�edm�tu zpr�vy napsat "USIS 1949".

Ocen�m i va�e koment��e nebo obr�zky va�� tvorby s vyu�it�m m�ho fontu, kter� m��ete zas�lat na stejnou adresu.

Klidn� font d�le distribuujte, ale pouze spole�n� s t�mto textem! V ��dn�m p��pad� font nijak nem��te a neupravujte.

M�jte se fajn!

LK
